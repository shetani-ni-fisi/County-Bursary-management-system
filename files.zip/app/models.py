class Bursary:
    def __init__(self, applicant_name, amount):
        self.applicant_name = applicant_name
        self.amount = amount