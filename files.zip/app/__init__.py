def run_app():
    print("Running the County Bursary Management System")