# County Bursary Management System

This is a simple Python application to manage county bursaries.

## Setup

1. Install the required packages:
   ```sh
   pip install -r requirements.txt
   ```

2. Run the application:
   ```sh
   python main.py
   ```